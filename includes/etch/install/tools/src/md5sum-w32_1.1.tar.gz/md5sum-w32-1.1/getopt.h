#define getopt pgp_getopt

int pgp_getopt(int argc, char **argv, char *opts);

